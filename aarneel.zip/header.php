 <div class="heading" align="right">Email : info@aarneel.com</div>
<div class="logo"><div style="width:123px; height:80px; margin-left:15%; float:left"> <img src="images/company logo.jpg" width="123px" /></div>
  <div align="right" style="padding-right:16%; padding-top:26px;"><a href="http://www.aarneel.com/#"> <img src="images/download.icon_.jpg" /></a></div>
  </div>
   <div class="menu">
<div class="menubar">
<div class="menu-item" id="home"> <a href="index.php">Home</a></div>
<div class="menu-item-2" id="aboutus"><a href="aboutus.php"l" > About Us</a></div>
<div class="menu-item-2" id="product"><a href="products.php">Product</a></div>
<div class="menu-item-2" id="roadsignage"><a href="roadsignages.php">Road Signage</a></div>
<div class="menu-item-2" id="contact"><a href="contactus.php">Contact Us</a></div>
</div>
</div>
