<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Aarneel technocraft Pvt Ltd. </title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Aarneel technocraft Pvt Ltd." />
	<meta name="description" content="Aarneel technocraft Pvt Ltd." />

	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<style type="text/css">a#vlb{display:none}</style>
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<script type="text/javascript" src="engine1/slider.js"></script>
	 
	 
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<!-- End W  HEAD section -->
	<script type="text/jscript">
	
	  $("document").ready(function(){
	$("#home").click(function(){
	 	$("body").load("index.html");
	});
	$("#aboutus").click(function(){
	$('body').load('start.html').show();
	});
	$("#product").click(function(){
	 	$("body").load("index.html");
	});
	$("#road").click(function(){
	 	$("body").load("index.html");
	});
	$("#contact").click(function(){
	 	$("body").load("index.html");
	});
	
	});
	</script>
</head>
<body style="background-color:#CAEBF4; width:99%">
<?php include 'header.php';?>
<!-- Start   BODY section -->
<div id="wowslider-container1">
	<div class="ws_images">
<span><img src="data1/images/aarneel_technocraft_pvt_ltd..jpg" alt="Aarneel Technocraft Pvt Ltd." title="Aarneel Technocraft Pvt Ltd." id="wows0"/></span>
<span><img src="data1/images/roll_forming_machine.jpg" alt="Roll Forming Machine" title="Roll Forming Machine" id="wows1"/></span>
<span><img src="data1/images/road_signages.jpg" alt="Road Signages" title="Road Signages" id="wows2"/></span>
<span><img src="data1/images/mig_pole_closing_machine.jpg" alt="MIG POLE CLOSING MACHINE" title="MIG POLE CLOSING MACHINE" id="wows3"/></span>
<span><img src="data1/images/our_associates.jpg" alt="Our Associates" title="Our Associates" id="wows5"/></span>
<span><img src="data1/images/swaged_poles.jpg" alt="Swaged Poles" title="Swaged Poles" id="wows7"/></span>
<span><img src="data1/images/decorative_pole.jpg" alt="Decorative Pole" title="Decorative Pole" id="wows8"/></span>
</div>
<div class="ws_bullets"><div>
<a href="#wows0" title="Aarneel Technocraft Pvt Ltd."><img src="data1/tooltips/aarneel_technocraft_pvt_ltd..jpg" alt="Aarneel Technocraft Pvt Ltd."/>1</a>
<a href="#wows1" title="Roll Forming Machine"><img src="data1/tooltips/roll_forming_machine.jpg" alt="Roll Forming Machine"/>2</a>
<a href="#wows2" title="Road Signages"><img src="data1/tooltips/road_signages.jpg" alt="Road Signages"/>3</a>
<a href="#wows3" title="MIG POLE CLOSING MACHINE"><img src="data1/tooltips/mig_pole_closing_machine.jpg" alt="MIG POLE CLOSING MACHINE"/>4</a>

<a href="#wows5" title="Our Associates"><img src="data1/tooltips/our_associates.jpg" alt="Our Associates"/>6</a>

<a href="#wows7" title="Swaged Poles"><img src="data1/tooltips/swaged_poles.jpg" alt="Swaged Poles"/>8</a>
<a href="#wows8" title="Decorative Pole"><img src="data1/tooltips/decorative_pole.jpg" alt="Decorative Pole"/>9</a>
</div></div>
<a style="display:none" href="http://wowslider.com">jQuery Photo Animation by   v2.0</a>
</div>
	<script type="text/javascript" src="engine1/script.js"></script>
	<!-- center content--->
	
	<div class="main-wrapper-center">
	<div style="margin:5px 0 5px 10px; color:#CCCCCC; font-size:24px">We Deals In : -</div>
	<div>
    <div class="box-1"><img src="images/road.jpg" width="200px"/></div>
	<div class="box-2"><img src="images/street.jpg" width="207"/></div>
	<div class="box-3"><img src="images/guard.jpg".jpg" width="207"/></div>
	<div class="box-4"><img src="images/shutring.jpg".jpg" width="207"/></div>
</div>
<div class="category">
<div class="menu-cat" style="margin-top:10px;"><a href="index.html">Home</a></div>
<div class="menu-cat"><a href="aboutus.html" title="About Us" target="_parent">About Us</a></div>
<div class="menu-cat">Street Light  </div>
<div class="menu-cat">Road signage  </div>
<div class="menu-cat">Shuttering Material </div>
<div class="menu-cat">Guards rails & Reflector</div>

</div>
<div class="aboutus">
<div style="color:#666666; font-size:24px; padding-left:10px"><u>Who we are ?</u></div>
<div style="margin:5px 10px 5px 10px; text-align:justify">
We are one of the eminent manufacturers and suppliers of Street Light Poles, Road signage & complete range of road furniture. We have earned its reputation as one of the preferred suppliers to professional sign shops worldwide serving the highway safety industry. We take reflective sheeting to the next level in performance and safety. <div style="margin:5px">
In our product range we offer Street Light Poles, Road signage & complete range of road furniture. These products are manufactured using quality basic material using the latest and advanced technology.</div>
</div>
</div>
</div>

<?php include 'footer.php';?>
    <!-- End  BODY section -->
</body>
</html>