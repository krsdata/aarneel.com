<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Aarneel technocraft Pvt Ltd. </title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Aarneel technocraft Pvt Ltd." />
	<meta name="description" content="Aarneel technocraft Pvt Ltd." />

	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<style type="text/css">a#vlb{display:none}</style>
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<script type="text/javascript" src="engine1/slider.js"></script>
	 
	 
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<!-- End W  HEAD section -->
	<script type="text/jscript">
	
	  $("document").ready(function(){
	$("#home").click(function(){
	 	$("body").load("index.html");
	});
	$("#aboutus").click(function(){
	$('body').load('start.html').show();
	});
	$("#product").click(function(){
	 	$("body").load("index.html");
	});
	$("#road").click(function(){
	 	$("body").load("index.html");
	});
	$("#contact").click(function(){
	 	$("body").load("index.html");
	});
	
	});
	</script>
</head>
<body style="background-color:#CAEBF4; width:99%">
<!-- Start   BODY section -->
<script type="text/javascript" src="engine1/script.js"></script>
	<!-- center content--->
	<?php include 'header.php';?>
<div class="main-wrapper-center" style="padding-bottom:5px;">
	<div style="margin:5px 0 5px 10px; color:#CCCCCC; font-size:24px">About Us  : -</div>
  <div style="margin:5px; padding:20px; text-align:justify; border:3px solid #CCCCCC; margin-bottom:5px;"> 
We are one of the eminent manufacturers and suppliers of Street Light Poles, Road signage & complete range of road furniture. We have earned its reputation as one of the preferred suppliers to professional sign shops worldwide serving the highway safety industry. We take reflective sheeting to the next level in performance and safety. <br /><br />

In our product range we offer Street Light Poles, Road signage & complete range of road furniture. These products are manufactured using quality basic material using the latest and advanced technology. Further, these are offered in customized solutions and can be purchased at industry leading prices from us. <br /><br />

Incepted with an objective to excel in our domain, we are heading to greater height day by day. We are assisted with wide distribution network owing to which our products have reached to each and every corner of the country. Our team of experts has put in their best efforts to make this possible. <br /><br />

Moreover, offering a variety of Lighting Poles and Outdoor Lighting Fixtures we offer includes Steel Tubular Poles (For Street Lighting & Transmission Lines), Cast Iron Poles, Decorative Lighting Poles, Octagonal Poles, High Mast Poles, M.S/G.I. Pipes, FRP Junction Box, Electric Poles, etc. <br />

We are flourishing at a fast pace under the due guidance of our knowledgeable MD. Mr. Samit Holkar. We have also carved a niche for ourselves among the topmost Pole Manufacturers in India. <br /> 

<h3>Resources: </h3> 

<p>Our up to date and well-equipped factory  with an area acquirement of 107640 Sq. feet, situated at Pithampur, Madhya Pradesh supported by latest machinery and testing facilities that enables us to fulfill the requirements of the clients on time. To supervise our units we have a team of trained and experienced technocrats that assure flawless production of the products. </p>
<p><u>Brief Introduction about Road Signage :</u><br /><br />
Road  signs which have the backing of law in India are incorporated in the Motor  Vehicles Act. 1988.<br />
The motor  vehicle act 1988 has covered all the sign warranty by different .traffic  situations. The designs of signs are fully dimensioned further, the signs have  uniformity, and mostly symbols are used to convey the message especially in the  case of regulatory signs.<br />
<u>Purpose of </u><u>Road </u><u>Signs</u><br /><br />
The  purpose of road signs is to promote road safety and efficiency by providing for  the orderly movement of all road  users on all roads in both urban and non-urban areas.<br />
<u>Principle  of Road Signs</u><br /><br />
This Code contain the  basic principle <br />that govern design and use of   road sign for all categories of road including expressways open to  public travel irrespective of road agency having jurisdiction.<br />
<u>A road  sign should meet five basic requirements:</u></p>
  <ul>
    <li>Fulfill a need</li>
    <li>Command attention</li>
    <li>Convey a clear and simple meaning</li>
    <li>Command respected from road user</li>
    <li>Give adequate  time for response. </li>
    <li>Maintenance of  road sign </li>
    <li>Placement and  Operation of Road Signs </li>
    <li>Uniformity of  Road Sighs </li>
    <li>Traffic  Engineering Study </li>
  </ul>
  <p>&nbsp;</p>
  <p>The decision to use a  particular sign at a particular location should be made on the basis of traffic  engineering study and after a very careful planning so that correct and uniform  signs are placed at required locations.<br />
    Authorities with responsibility for traffic control  that do not have in-house engineering assistance can take help from engineer.</p>
  <p><br />
  </p>
  </div>
</div>
<?php include 'footer.php' ;?>
	<!-- End  BODY section -->
</body>
</html>