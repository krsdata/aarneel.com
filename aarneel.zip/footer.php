<div class="footer">
<div class="footer-content">
<div style="color:#CCCCCC; font-size:18px; margin-top:5px; cursor:pointer">Quick Link</div>
<ul type="square" style="color:#CCCCCC">
<div style="margin-left:50px; margin-top:10px; cursor:pointer"><li> Road Signage</li></div>
<div style="margin-left:50px;cursor:pointer"><li>Street Light Pole</li></div>
<div style="margin-left:50px;cursor:pointer"><li>Guards rails and Reflector</li></div>
<div style="margin-left:50px;cursor:pointer"><li>Shuttering Material</li> </div>
</ul>
<div style="text-align:left;color:#FFFFFF">� Copyright 2013
Aarneel Technocraft Pvt Ltd
</div>
</div>
<div class="footer-content2">
<strong>Reach Us Address : </strong> 
<div style="margin:10px 0px 0px 90px;">Plot No-16 Sector-2,<br /> Industrial Area, Pithampur <br />(M.P.) 452012<br />
Email : info@aarneel.com<br />
www.aarneel.com<br />
</div></div>

</div>