o<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN"
	"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
	<title>Aarneel technocraft Pvt Ltd. </title>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="Aarneel technocraft Pvt Ltd." />
	<meta name="description" content="Aarneel technocraft Pvt Ltd." />

	<link rel="stylesheet" type="text/css" href="engine1/style.css" />
	<style type="text/css">a#vlb{display:none}</style>
	<script type="text/javascript" src="engine1/jquery.js"></script>
	<script type="text/javascript" src="engine1/slider.js"></script>
	 
	 
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<!-- End W  HEAD section -->
	<script type="text/jscript">
	
	  $("document").ready(function(){
	$("#submit").click(function(){
	var v=$("input:text[name=name]").val();
	var v1=$("input:text[name=email]").val();
	var v2=$("input:text[name=contact]").val();
	 	if(v=='')
		{
		alert("Please enter your Name ");
		return false;
		}
		if(v1=='')
		{
		alert("Please enter your Email ID");
		return false;
		}
		if(v2=='')
		{
		alert("Please enter your Contact Number");
		return false;
		}
		});
	
	});
	</script>
</head>
<body style="background-color:#CAEBF4; width:99%">
<?php include 'header.php';?>
<!-- Start   BODY section -->
<div class="services" style="min-height:1510px; background-color:#FFFFFF;">
<div style="margin:5px 15px;text-shadow:0px 3px 3px #CEDAE6;color:#AC4234; border-bottom:3px solid"> <h1>Road traffic and safety Signages</h1></div>
<div style="min-height:600px; padding:15px; text-align:justify;background-color:#FFFFFF;"><strong><p>Introduction:</p></strong>
Road signs which have the backing of law in India are incorporated in the Motor Vehicles Act. 1988.
The motor vehicle act 1988 has covered all the sign warranty by different .traffic situations. The designs of signs are fully dimensioned further, the signs have uniformity, and mostly symbols are used to convey the message especially in the case of regulatory signs.
  <strong><p>Purpose of Road Signs</p></strong> The purpose of road signs is to promote road safety and efficiency by providing for the orderly movement of all road users on all roads in both urban and non-urban areas.
  <strong><p>Principle of Road Signs</p></strong>
This Code contain the basic principle that govern design and use of  road sign for all categories of road including expressways open to public travel irrespective of road agency having jurisdiction.
<strong><p>A road sign should meet five basic requirements:</p>
<p>
  
  <ul>
    <li>Fulfill a need</li>
    <li>Command attention</li>
    <li>Convey a clear and simple meaning</li>
    <li>Command respected from road user</li>
    <li>Give adequate  time for response. </li>
    <li>Maintenance of  road sign </li>
    <li>Placement and  Operation of Road Signs </li>
    <li>Uniformity of  Road Sighs </li>
    <li>Traffic  Engineering Study </li>
  </ul>
</p>
</strong>
<div style="background-color:#FFFFFF" align="center"><img src="images/trfic.jpg" alt=""  align="middle"/></div>
</div>
</div>
<?php include 'footer.php' ;?>
<!-- End  BODY section -->
</body>
</html>